# Import Libraries below





# Define flask 


# Define upload_form() and route the webapp 






# Define upload_video() to get video in defined folder and route the webapp  








# Define display_video() to Display video in defined folder and route the webapp  





if __name__ == "__main__":
    app.run(debug=True)
